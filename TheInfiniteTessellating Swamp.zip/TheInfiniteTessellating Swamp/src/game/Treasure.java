package game;

public class Treasure {

	private int tresX;
	private int tresY;

	public Treasure(int tresx, int y) {
		this.setTresX(tresx);
		this.setTresY(tresY);

	}

	public int getTresX() {
		return tresX;
	}

	public void setTresX(int tresX) {
		this.tresX = tresX;
	}

	public int getTresY() {
		return tresY;
	}

	public void setTresY(int tresY) {
		this.tresY = tresY;
	}
}
